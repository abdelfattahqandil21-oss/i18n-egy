import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class I18nEgy {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.26", ngImport: i0, type: I18nEgy, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.26", type: I18nEgy, isStandalone: true, selector: "lib-i18n-egy", ngImport: i0, template: `
    <p>
      i18n-egy works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.26", ngImport: i0, type: I18nEgy, decorators: [{
            type: Component,
            args: [{ selector: 'lib-i18n-egy', imports: [], template: `
    <p>
      i18n-egy works!
    </p>
  ` }]
        }] });

/*
 * Public API Surface of i18n-egy
 */

/**
 * Generated bundle index. Do not edit.
 */

export { I18nEgy };
//# sourceMappingURL=i18n-egy.mjs.map
