import * as i0 from '@angular/core';

declare class I18nEgy {
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nEgy, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<I18nEgy, "lib-i18n-egy", never, {}, {}, never, never, true, never>;
}

export { I18nEgy };
